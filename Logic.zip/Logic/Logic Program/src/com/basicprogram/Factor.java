package com.basicprogram;

public class Factor {

	public static void main(String[] args) {
		int n=10;
		int c=0;
		for (int i = 1; i <= n; i++) {
			if(n%i==0)
			{
				System.out.print(i+" ");
			}
			
		}
		

	}

}
