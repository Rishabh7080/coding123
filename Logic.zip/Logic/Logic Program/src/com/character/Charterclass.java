package com.character;

public class Charterclass {
	public static void main(String[] args) {
		
	/* 'A'=65 'a'=97
	    'Z'=90  'b'=122
	    '0'=48  '9'=57
	 
	 */
    System.out.println((char)'A');// type costing but char that why return char 
    System.out.println((int)'A');// type costing Int type why return int value
    System.out.println((int)'a');// type costing is int type thats why int value
    System.out.println((int)' ');// one space represent the space ascii value is 32 its is say
  
    
    System.out.println((char)65);// type costing but char tha twhy return char 
    System.out.println((char)49);// type costing but char that why return char 
    System.out.println((char)99);// type costing but char that why return char 
    
    System.out.println('A'+'A');// internally type costing happen so its change return type is int  valiue
    System.out.println((char)'A'+2);// type costing but its only first becoz but by default 2 is intger type so inter not assingn return int value 
    System.out.println((char)('A'+2));// type costing but char thatwhy return char 
    System.out.println((char)('F'+' '));// type costing but char thatwhy return char  by default space value is 32
    
    
    char a=Character.toUpperCase('a');
    System.out.println(a);// return type is char
    char b=Character.toUpperCase('*');
    System.out.println(b);// return type is char as its printed 
    char c=Character.toUpperCase('A');
    System.out.println(c);// return type is char as its printed 
    
    
    
    
    boolean s=Character.isLetter('a');
    		System.out.println(s);
    
    /*
     * isUpperCase('A');
     * isLowerCaes('a');
     * isDigit('6');
     * isLetterOrDigit('a');
     * isLetter('a');
     * 
     */
    
    
	System.out.println(2+3+"risabh"+2+3);
	
	
//	String s=5;
//	System.out.println(s); compile time error  int cant be converted string
	String f=String.valueOf(5);
	System.out.println(f);// string value converted anythings is string
	
	
	
	
	
	}
}
