package com.collection;

import java.util.ArrayList;
import java.util.HashSet;

public class HaspSet_Convert_ArrayList {
public static void main(String[] ars) {
	HashSet<String> hs=new HashSet<String>();// set dublicate not allow
	hs.add("ram");
	hs.add("rishabh");
	hs.add("pintu");
	hs.add("rishabh");// its not maintain the insertion
	System.out.println(hs);//[rishabh ram pintu]
	// convrt the hasset to arraylist
	ArrayList<String> al= new ArrayList<String>(hs);
	System.out.println(al);
}


}

