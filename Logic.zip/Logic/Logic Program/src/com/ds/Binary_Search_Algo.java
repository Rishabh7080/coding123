package com.ds;

public class Binary_Search_Algo{

	public static void main(String[] args) {
	int a[]= {10,20,30,40,50,60,70,80,90};
	  int search=60; 
	int li=0;
	  int hi=a.length-1;
	  int mi=(li+hi)/2;
	  while(li<=hi)
	  {
		  if (a[mi]==search) {
			System.out.println("find at pos"+mi+"at element");
			break;
		}
		  else if (a[mi]<search) {
			  li=mi+1;
			
		}
		  else {
		  
			  hi=mi-1;
		  }
		  mi=(hi+li)/2;
			  
		  
	  }
	  if (li>hi) {
		  System.out.println("not found");
		
	}
	  

	}

}
