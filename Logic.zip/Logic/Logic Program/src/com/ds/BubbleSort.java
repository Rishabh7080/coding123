package com.ds;

public class BubbleSort {

	public static void main(String[] args) {
		int a[]= {5,6,8,24,2,3,4,6,8,4,56};
		
		for(int i=0;i<a.length-1-i;i++)
		{
			for(int j=0;j<a.length-1;j++)
			{
				if(a[j+1]<a[j])
				{
					int temp=a[j+1];
					a[j+1]=a[j];
					a[j]=temp;
				}
			}
		}
		for(int item:a)
		{
			System.out.print(item+" ");
		}
	}
}
		


