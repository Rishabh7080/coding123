package com.ds;
public class InsertionSort {
	public static void main(String[] args) {
	int a[]= {5,6,3,6,2,8};
	int temp;
	
	for (int i = 0; i<a.length-1; i++) {
		temp=a[i];
		int j=i-1;
		while(j>=0&&a[j]>temp) {
			a[j+1]=a[j];
			j--;
		}
			a[j+1]=temp;
		}
		for (int i = 0; i <a.length-1; i++) {
		System.out.print(a[i]+"\t");
		
	}
}

}
