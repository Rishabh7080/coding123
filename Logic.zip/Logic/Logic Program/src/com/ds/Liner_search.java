package com.ds;

import java.util.Scanner;

public class Liner_search {

	public static void main(String[] args) {
		int arr[]= {10,54,56,40,73,46,25,82};
		int item,flag=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the item");
		item=sc.nextInt();
		for (int i = 0; i < 8; i++) {
			if (arr[i]==item) {
				      flag=i+1;
				      break;
			}
				      else
				    	  flag=0;
				
			}
			if (flag!=0) {
				System.out.println("fing at pos of"+flag);
			}else
				System.out.println("not found");
		}

	

}
