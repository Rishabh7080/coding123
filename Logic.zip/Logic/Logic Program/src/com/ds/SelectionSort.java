package com.ds;

public class SelectionSort {

	public static void main(String[] args) {

		int [] a={4,5,5,6,2,6,-5};
		int n=a.length;
		for(int i=0;i<n-1;i++)
		{
		int	 MidIndex=i;
			for(int j=i;j<n;j++)
			{
				if(a[j]<a[MidIndex])
				{
					MidIndex=j;
				}
			}
			int temp=a[i];
			a[i]=a[MidIndex];
			a[MidIndex]=temp;
			
		}
		for(int e:a)
		{
			System.out.print(e+" ");
		}
	}

}
