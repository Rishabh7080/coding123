package com.ds;

public class SinglyLinkList {
	
	private static class ListNode{
		private int data;
		private ListNode next;
		// create constructor
		public ListNode(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void dispaly(ListNode head)
	{
		if(head==null)
		{
			return;
		}
		ListNode current=head;
		while(current!=null)
		{
			System.out.print(current.data+"-->");
			current=current.next;
		}
		System.out.println(current);
	}
	public static int length(ListNode head)
	{
		if(head==null)
		{
			return 0;
		}
		ListNode current=head;
		int count=0;
		while(current!=null)
		{
			count++;
			current=current.next;
			
		}
		return count;
	}
	public static ListNode insertAtFirst(ListNode head,int data)
	{
		ListNode newNode =new ListNode(data);
		if(head==null)
		{
			return newNode;
		}
		newNode.next=head;
		head=newNode;
		return head;
	}
	public static ListNode insertAtEnd(ListNode head,int data)
	{
		ListNode newNode=new ListNode(data);
		if(head==null)
		{
			return newNode;
		}
		ListNode current=head;
		while(null!=current.next)
		{
			current=current.next;
		}
		current.next=newNode;
		return head;
		
	}
	public static ListNode reverse(ListNode head)
	{
		if(head==null)
		{
			return head;
		}
		ListNode current=head;
		ListNode privious=null;
		ListNode next=null;
				while(current!=null){
			   next=current.next;
			   current.next=privious;
			   privious=current;
			   current=next;
				}
		return privious;
	}
	public static ListNode deletFist(ListNode head)
	{
		if(head==null)
		{
			return head;
		}
		ListNode temp=head;
		head=head.next;
		temp.next=null;
		return temp;
	}
	public static ListNode deletLast(ListNode head)
	{
		if(head==null)
		{
			return head;
		}
		ListNode last=head;
		ListNode PrevoistToLast=null;
		while(last.next!=null)
		{
			PrevoistToLast=last;
			last=last.next;
		}
		PrevoistToLast.next=null;
		return last;
	}
	public static void main(String[] args) {
		// now craet to Linked List
		ListNode head=new ListNode(10);
		ListNode secont=new ListNode(8);
		ListNode third=new ListNode(1);
		ListNode fourth=new ListNode(11);
		head.next=secont;
		secont.next=third;
		third.next=fourth;
		SinglyLinkList sl=new SinglyLinkList();
		sl.dispaly(head);
//		System.out.println(SinglyLinkList.length(head));
//		ListNode newHead=sl.insertAtFirst(head,15);
//		sl.dispaly(newHead);
//		ListNode newhead=sl.insertAtEnd(head, 20);
//		sl.dispaly(newHead);
//		ListNode revHead=sl.reverse(head);
//		sl.dispaly(revHead);
		ListNode First=sl.deletFist(head);
		sl.dispaly(First);
		
		
	}
}