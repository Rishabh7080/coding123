package com.geeksforgeeks;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayRev {
public static void main(String[] args) {
	
Scanner sc=new Scanner(System.in);
int a[]= {2,4,56,58,85};

String s=Arrays.toString(a);
String v=new String(s);
   s=s.replace(",", "");
   s=s.replace(" ", "");
   s=s.replace("]", "");
    s=s.replace("[","");
   System.out.println(s);
   StringBuffer sb=new StringBuffer(s);
   sb.reverse();
   System.out.println(sb);
  
	
	
}
}

