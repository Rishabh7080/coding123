package com.geeksforgeeks;

import java.util.Arrays;
public class Array_is_Sorted_Or_not 
{
	public static void main(String[] args)
	{
		
	
             // int a[]= {1,2,3,4,5};
             int a[]= {1,5,3,4,5};
            int f=1;	
            for (int i = 0; i < a.length-1; i++)
            {
	             if((a[i])>(a[i+1]))
                  {
                     f=0;
                      break;
                   }
              }
            if(f==1)
         System.out.println("yes");
            else {
				System.out.println("no");
			}

  }
	
}
	 


