package com.geeksforgeeks;

public class Array_reverse {

	public static void main(String[] args) {
		int a[]= {1,5,3,4,5};
		String t="";
		for (int i = a.length-1; i>=0; i--) {
			System.out.print(a[i]+" ");
		}
		System.out.println();
	}

}
