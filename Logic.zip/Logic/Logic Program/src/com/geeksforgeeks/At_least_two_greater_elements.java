package com.geeksforgeeks;

import java.util.Arrays;

public class At_least_two_greater_elements {
	public static void main(String[] args) {
		
	
	int a[]= {2, 8, 7, 1, 5};
	int n=a.length;
	Arrays.sort(a);
	for (int i = 0; i < a.length-2; i++) {
		System.out.print(a[i]+" ");
		
	}
	System.out.println();
	}
}
