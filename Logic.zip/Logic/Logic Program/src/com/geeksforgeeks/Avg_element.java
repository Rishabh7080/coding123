package com.geeksforgeeks;

public class Avg_element {

	public static void main(String[] args) {
		int a[] = {10, 20, 30, 40, 50};
		int sum=0;
		
		for(int i=0;i<a.length;i++)
	    {
			sum=sum+a[i];
	        int c=sum/(i+1);
	      System.out.print(c+" ");
	      
	}
	}
}


