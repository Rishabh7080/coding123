package com.geeksforgeeks;

import java.util.Arrays;

public class COunt_occuernece {

	public static void main(String[] args) {
		int a[]= {1,2,2,3,4,5};
		Arrays.sort(a);
		int k=2;
		int c=0;
		for (int i = 0; i < a.length; i++) {
			if(a[i]==k)
				c++;
		}
		if(c>0)
		{
			System.out.println(c);
		}
		else {
			System.out.println("-1");
		}
	}

}
