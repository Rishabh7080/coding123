package com.geeksforgeeks;

import java.util.Arrays;

public class CheakTwoAraray_IS_equal_not {

	public static void main(String[] args) {
		int a[]= {1, 2, 5, 4, 0};
		int b[]= {0, 2, 7, 5, 1};
		Arrays.sort(a);
		Arrays.sort(b);
		if(Arrays.equals(a, b))
		{
			System.out.println("1");
		}
		else {
			System.out.println("0");
		}

	}

}
