package com.geeksforgeeks;

public class CountNo_which_is_BiggerThan_NO {

	public static void main(String[] args) {
		int a[]= {1 ,2, 3, 4, 5, 6, 7, 8};
		int n=a.length;
		int k=5;
		int c=0;
		for (int i = 0; i <n ; i++) {
			if (a[i]<=k) {
				c++;
			}
			
		}
		
   System.out.println(c);
	}

}
