package com.geeksforgeeks;

public class Count_NO_Which_is_LessTHan_equalThank {

	public static void main(String[] args) {
		int a[]= {1,5,3,3,4,5,3};
		int k=3;
		int t=0;
		int s=0;
		for (int i = 0; i < a.length; i++) {
			if(a[i]<=k)
				t++;
			if(a[i]>=k)
				s++;
			}
System.out.println(s+" "+t);
	}

}
