package com.geeksforgeeks;

public class Count_Which_Occure_5_time {

	public static void main(String[] args) {
		int []a= {1,2,3,3,3,3,3,5,9,9,9,9,9,10};
		int c=0;
		for (int i = 0; i < a.length-1; i++) {
			
			if (a[i]==a[i+1]) {
				c=a[i];break;
			}
		}
		
			System.out.println(c);
		}
		
	

}
