package com.geeksforgeeks;

public class Fascinating_Number {

	public static void main(String[] args) {
		int n=5;
		//int n=192;
		int n1=n*2,n2=n*3;
		String s =""+n+n1+n2;
		int c=0;
		
		
		for (int j = 0; j <=9; j++) 
			
		
		{
			if (s.contains(Integer.toString(j))) {
				c++;
			}
			
			
		}
		if(c==9)
		
			System.out.println("Fascinating_Number");
		
		else 
			System.out.println("Not Fascinating_Number");
		
		
	}

}
