package com.geeksforgeeks;

public class FindMissingNumberInArray {
	public static void main(String[] args) {
		int a[]= {1 ,2, 3, 5};
		int sum=0;
		for (int i = 0; i < a.length; i++) {
			sum+=a[i];//11
		}
		int nsum=((a.length+1)*(a.length+2))/2;
		//          5*6/2=15
		System.out.println(nsum-sum);//15-11=4
	}
	

}
