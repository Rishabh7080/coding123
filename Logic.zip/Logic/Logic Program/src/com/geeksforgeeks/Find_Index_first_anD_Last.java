package com.geeksforgeeks;

public class Find_Index_first_anD_Last {

	public static void main(String[] args) {
		int a[]= {1,5,3,3,4,5,3};
		int k=3;
		
		int i=0;
		int j=0;
		for ( i = 0; i < a.length; i++)
		{
			  if(a[i]==k)
			  {
			   break;
			  }
		}
		for (j = a.length-1; j>=0; j--)
		{
		   if (a[j]==k) 
		   {
					break;
			}
		}
				System.out.println(i+" "+j);
			}
			
			 
	
	}


