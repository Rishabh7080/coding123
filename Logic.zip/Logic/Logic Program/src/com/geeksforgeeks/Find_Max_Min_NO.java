package com.geeksforgeeks;

import java.util.Arrays;

public class Find_Max_Min_NO {

	public static void main(String[] args) {
		int a[]= {5,6,2,4,6,7};
		int n=a.length;
//		Arrays.sort(a);
//		System.out.println(a[n-1]+" "+a[0]);
		
		for (int i = 0; i < a.length-1; i++) {
			for (int j = 0; j < a.length-1; j++) {
				if(a[j]>a[j+1]) {
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
				}
				
			}
			
		}
		System.out.println(a[n-1]+" "+a[0]);

	}

}
