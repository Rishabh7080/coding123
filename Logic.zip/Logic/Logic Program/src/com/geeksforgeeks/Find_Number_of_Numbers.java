package com.geeksforgeeks;

import java.util.Arrays;

public class Find_Number_of_Numbers {

	public static void main(String[] args) {
		int a[]= {11, 12 ,13, 14, 15 };
		
		int  n=a.length;
		int k=1;int  m=0;
		for (int i = 0; i < a.length; i++) {
			while(a[i]!=0)
			{
				int rem=a[i]%10;
				a[i]=a[i]/10;
				if(rem==k)
					m=m+1;
			}
		}System.out.println(m);
	}

}
