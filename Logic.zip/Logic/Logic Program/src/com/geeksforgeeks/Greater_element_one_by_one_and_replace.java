package com.geeksforgeeks;

import java.util.Arrays;

public class Greater_element_one_by_one_and_replace {
	public static void main(String...agrs)
	{
		int a[]= {16 ,17 ,4 ,3 ,5, 2};
		System.out.println(Arrays.toString(a));
		
		for (int i = 0; i < a.length-1; i++) {
			int max=0;
			for (int j = i+1; j < a.length; j++) 
			{
						if (a[j]>max) {
							max=a[j];
						}	
						
			}
			System.out.print(max+" ");
		}
		System.out.println("-1");
	}
}
