package com.geeksforgeeks;

public class Maximum_Index {

	public static void main(String[] args) {
		int a[]= {34 ,8 ,10, 3, 35, 80, 56 ,33, 1};
		  
			int currmax=0,max=0,i=0,j=0;
			for(i=0;i<a.length;i++){
			    for(j=i+1;j<a.length;j++){
			        if(a[i]<=a[j]){
			            currmax=j-i;
			        }
			        if(currmax>max){
			            max=currmax;
			        }
			    }
			}
			System.out.println(max);
			}
			
		
	}


