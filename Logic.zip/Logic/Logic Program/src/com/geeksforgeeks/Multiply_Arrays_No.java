package com.geeksforgeeks;

public class Multiply_Arrays_No {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		int n=a.length;
		int mul=1;
		for (int i = 0; i < a.length; i++) {
			mul=mul*a[i];
		}
    System.out.println(mul+" ");
	}

}
