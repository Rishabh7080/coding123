package com.geeksforgeeks;

public class Multiply_Mid_to_Mid_and_add {

	public static void main(String[] args) {
		int a[]= {1,2,3,4};
		int n=a.length/2;
		int s1=0, s2=0;
		for (int i = 0; i < a.length; i++) {
			if(i<n)
			{
				s1=s1+a[i];
			}
			else {
				s2=s2+a[i];
			}
		}
		System.out.println(s1*s2);

	}

}
