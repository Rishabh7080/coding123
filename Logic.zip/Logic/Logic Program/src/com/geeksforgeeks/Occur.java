package com.geeksforgeeks;

import java.util.Arrays;
import java.util.Scanner;

public class Occur {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	//int n=sc.nextInt();
	//while (n-->0) {
		String s =sc.next();
		char a[]=s.toCharArray();
		Arrays.sort(a);
		s=new String(a);
		
		for (int i = 0; i < s.length(); ) {
			char c=s.charAt(i);
			int occ=s.lastIndexOf(c)+1;
			System.out.print(""+c+occ);
			i=s.lastIndexOf(c)+1;
		//}
	
		
	}
}
}
