package com.geeksforgeeks;

public class Pair_of_Sum_K {

	public static void main(String[] args) {
		int arr1[] = {1, 3, 5, 7}; 
        int arr2[] = {2, 3, 5, 8}; 
        int m = arr1.length; 
        int n = arr2.length; 
        int x = 10; 
        int count=0;
        for (int i = 0; i < m; i++) {
        	for (int j = 0; j < n; j++) {
        		if ((arr1[i] + arr2[j]) == x)  
                    count++; 
				
			}
			
		}
        System.out.println(count);
	}

}
