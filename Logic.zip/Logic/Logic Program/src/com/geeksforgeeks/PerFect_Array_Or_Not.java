package com.geeksforgeeks;

public class PerFect_Array_Or_Not {

	public static void main(String[] args) {
		int a[]= {1, 2, 3 ,2, 1};
		//int a[]= {1, 2 ,3 ,4 ,5};
		int n=a.length;
		int b=n;
		int e=b-1;
		int sum=0;
		for (int i = 0; i < a.length; i++) {
			if(a[i]==a[e])
			{
				sum++;
			}
			e--;
		}
		if (sum==n) {
			System.out.println("perfect");
			
		}
		else {
			System.out.println("Not Perfect");
		}
	}

}
