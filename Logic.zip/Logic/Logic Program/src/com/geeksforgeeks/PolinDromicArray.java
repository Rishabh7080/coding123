package com.geeksforgeeks;

import java.util.Scanner;

public class PolinDromicArray {

	public static void main(String[] args) {
		int a[]= {1111,222,333};
		int n=a.length;
		PolimdromArray(a,n);
  }

	private static void PolimdromArray(int[] a, int n) {
		/*for (int item:a) {
			int temp=item;
			int rev=0;
			while(item>0)
			{
				int rem=item%10;
				rev=(rev*10)+rem;
				item=item/10;
			}
			if(rev==temp)
				continue;
			else {
				System.out.println("Not Pindrom");
			}
			
		}
		System.out.println(" Polidrom");
		
	}
*/
		  {
              
	            
	             int[] arr = a;
	            
	             
	             
	             for(int i=0;i<n;i++)
	             {
	                StringBuilder sb = new StringBuilder();
	                sb.append(arr[i]);
	                if(arr[i] != Integer.valueOf(sb.reverse().toString()))
	                {
	                    System.out.println("Not Pildrome");
	                    break;
	                }
	             }
	             
	             System.out.println("Polidrome");
	           
	    }

	
	}
}


