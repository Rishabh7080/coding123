package com.geeksforgeeks;

import java.util.Arrays;

public class Print_the_left_element {

	public static void main(String[] args) {
		int a[]= {7, 8 ,3 ,4, 2, 9 ,5};
		int n=a.length;
		Arrays.sort(a);
		if(n%2==0)
		{
		      System.out.println(a[(n/2)-1]) ; 
		}
		else {
			System.out.println(a[n/2]);
		}
		
	}

}
