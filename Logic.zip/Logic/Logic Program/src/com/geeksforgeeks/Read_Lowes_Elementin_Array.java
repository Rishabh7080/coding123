package com.geeksforgeeks;

import java.util.Arrays;

public class Read_Lowes_Elementin_Array {
	public static void main(String[] args) {
		
	
	int a[]= {2, 8, 7, 1, 5};
	int n=a.length;
	int k=5;
	 String t="";
	 Arrays.sort(a);
	for (int i = 0; i <n ; i++) {
		if (a[i]<=k) {
			t=t+a[i];
		}
		
	}
	
System.out.println(t);
	}


}



