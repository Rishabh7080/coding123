package com.geeksforgeeks;



public class ReapatedArray
{

	public static void main(String[] args)
	{
	
		String s="ApPle";
		s=s.toUpperCase();
         String t=" ";
        
         
        for (int i = 0; i <s.length(); i++) {
        	 char c=s.charAt(i);
        	 if(t.contains(""+c))
        	 {
        		 System.out.println(t=t+c);
        	 }
        	 
         }
        	 
         }
			
			
		
}
		
	


