package com.geeksforgeeks;



public class RemoveDublicatUnsoettedArray {

	public static void main(String[] args) {
		int a[]= {1,5,3,4,5};
		int res=0;
		int flag=0;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]==a[j])
				{
					flag=1;
					break;
				}
				else {
					System.out.print(a[j]+" ");
				}
			}
			
		}
		

	}

}
