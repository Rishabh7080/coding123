package com.geeksforgeeks;

import java.util.Arrays;

public class Replace_No {

	public static void main(String[] args) {
		int n=10025;
		System.out.println(n);
		String s=""+n;
		s=s.replace("0", "5");
		n=Integer.parseInt(s);
		System.out.println(n);

	}

}
