package com.geeksforgeeks;

public class Rotate_Array {

	public static void main(String[] args) {
	int a[]= {1,2,3,4,5};
	int d=2;
	int n=a.length;
	StringBuffer sb= new StringBuffer();
	for (int i = d; i < n; i++) {
		
		sb.append(a[i]+" ");
	}
 for (int i = 0; i < d; i++) {
	sb.append(a[i]+" ");
}
 System.out.println(sb);
	}

}
