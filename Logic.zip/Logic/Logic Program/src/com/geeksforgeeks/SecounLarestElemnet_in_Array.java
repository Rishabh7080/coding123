package com.geeksforgeeks;

import java.util.Arrays;

public class SecounLarestElemnet_in_Array {

	public static void main(String[] args) {
		
int a[]= {2,4,5,6,8,7,9};
//String s=Arrays.toString(a);
Arrays.sort(a);
System.out.println(a[a.length-2]);
	}

}
