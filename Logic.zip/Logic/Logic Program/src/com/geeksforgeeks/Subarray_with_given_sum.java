package com.geeksforgeeks;

public class Subarray_with_given_sum {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		int sum=12;
		int csum=0,header=0,flag=0;
		for (int i = 0; i < a.length; i++) {
			csum=csum+a[i];
			while(csum>sum)
			{
				csum=csum-a[header];
				header++;
			}
			if(csum==sum)
			{ flag=1;
				System.out.println((header)+" "+(i+1));
				break;
			}
		}
             if (flag==0) {
				System.out.println("-1");
			}
	}

}
