package com.geeksforgeeks;

import java.util.Scanner;

public class SumArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sum=0;
//	    int st=sc.nextInt();
	    int en=5;
	    for(int i=1;i<=en;i++)
	    {
	        sum=sum+i;
	    }
	    System.out.print(sum);
	    System.out.println();
	    
	}
   
	}
	


