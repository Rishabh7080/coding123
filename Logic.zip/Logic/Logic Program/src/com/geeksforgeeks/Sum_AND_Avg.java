package com.geeksforgeeks;

public class Sum_AND_Avg {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		
		//int n=a.length;
		int n=a.length;
		int t=(n*(n+1)/2);
		double d=t/n;
		
		System.out.printf("%d %.2f\n",t,d);
		//double avg=sum)/a.length;
		//System.out.printf("%d %.2f\n",sum,avg);

	}

}
