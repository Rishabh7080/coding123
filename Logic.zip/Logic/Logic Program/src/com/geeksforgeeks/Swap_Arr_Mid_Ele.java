package com.geeksforgeeks;

public class Swap_Arr_Mid_Ele {

	public static void main(String[] args) {
		
		int a[]= {1 ,2, 3, 4, 5, 6, 7, 8};
		int n=a.length;
		int k=3;
		int i=k-1;
		int j=n-k;
		int temp=a[i];
		a[i]=a[j];
		a[j]=temp;
		for (int i1 = 0; i1 < n; i1++) {
			System.out.print(a[i1]+" ");
		}
		

	}

}
