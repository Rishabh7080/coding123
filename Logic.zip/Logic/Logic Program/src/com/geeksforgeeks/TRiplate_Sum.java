package com.geeksforgeeks;

public class TRiplate_Sum {

	public static void main(String[] args) {
		int a[]= {0 ,-1,2,-3,1};
		for (int i = 0; i < a.length; i++) {
			if (a[i]+a[i+1]+a[i+2]==0) {
				System.out.print("0");
				i=i+2;
			}
			else {
				System.out.print("1");
			}
			
		}
		System.out.println();
	}

}
