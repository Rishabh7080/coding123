package com.geeksforgeeks;

public class Test {

	public static void main(String[] args) {
		Test a=new Test();
		a.Cheak(null);
	}

	public String  Cheak(String s) {
		if(s.length()==0||s==null)
		{
			return "empty";
		}
		else {
			return "Not";
		}
		// TODO Auto-generated method stub
		
	}

}
