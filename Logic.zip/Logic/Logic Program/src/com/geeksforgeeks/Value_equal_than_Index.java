package com.geeksforgeeks;

import javax.sound.midi.Soundbank;

public class Value_equal_than_Index {

	public static void main(String[] args) {
		int a[]= {15 ,2 ,45, 12, 7};
boolean flag=false;
		for (int i = 0; i < a.length; i++) {
			if (a[i]==(i+1)) {
				flag=true;
			System.out.println(a[i]+ " ");
				
			}
		}
		
			
		}
	}


