package com.mathinbuiltmethod;

import java.math.BigInteger;

public class BigIntegerPredefind {

	public static void main(String[] args) {
		BigInteger a= BigInteger.valueOf(5);
		BigInteger b=new BigInteger("8");
		System.out.println(a.multiply(b));
		System.out.println(a.add(b));
		System.out.println(a.subtract(b));
		System.out.println(a.divide(b));
		System.out.println(a.mod(b));
		System.out.println(a.pow(55));
	}

}
