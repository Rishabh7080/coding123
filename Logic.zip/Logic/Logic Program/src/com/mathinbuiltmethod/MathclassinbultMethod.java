package com.mathinbuiltmethod;




public class MathclassinbultMethod {

	public static void main(String[] args) {
		
		System.out.println(Math.PI);//return type double

		
		System.out.println(Math.sqrt(8));//return type double
		
		
		System.out.println(Math.cbrt(8));////return type double
	
	
	
	
	     System.out.println(Math.max(5, 70.0));////return type double
	    
	     
	      System.out.println(Math.min(-5, 6));////return type double
	
	
	       System.out.println(Math.abs(6));//return type double
	       //it is always print +ve no if no is negative then its print +ve no
	
	
	          System.out.println(Math.pow(2, 5));////return type double
	
	
	           System.out.println(Math.hypot(3,4));////return type double
	           // root of 3 ka squr and 4 ka squre  9+16=25; if root of 25 is 5
	           
	           System.out.println(Math.round(6.545));////return type Integer
	           // its show near point of value like as 5.4 is show 5 but if 5.6 then its 6.
	           
	           
	           System.out.println(Math.floor(5.6));////return type double
	           // its show floor no. if you 5.1then also 5 if you  5.9 then also you 5.
	           
	           
	           System.out.println(Math.ceil(2.3));//return type double
	           // always upper ceil 2.3=3
	           
	           System.out.println(Math.random());////return type double
	           // is always shown 0 to 0.2 something
	           
	           System.out.println(Math.log(100));//return type double
	           
	           System.out.println(Math.log10(100));////return type double
	           
	           
	           System.out.println(Math.acos(6.0));//non why
	           
	           
	           System.out.println(Math.addExact(5, 6));//  return int add two element
	           
	           System.out.println(Math.asin(5));// why
	           
	           System.out.println(Math.atan(5));// why
	           
	           System.out.println(Math.copySign(6, 3));//return type double//copy first no to other no
	           
	           System.out.println(Math.class);

	           


	          
	          
	          
	          
	          
	
	}

}
