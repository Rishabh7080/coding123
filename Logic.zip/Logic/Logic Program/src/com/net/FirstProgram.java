package com.net;

import java.util.Scanner;

public class FirstProgram {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a no");
		int n=sc.nextInt();
		System.out.println("Enter the secound no");
      int m=sc.nextInt();
      int c=m+n;
      System.out.println(c);
		
	}

}
