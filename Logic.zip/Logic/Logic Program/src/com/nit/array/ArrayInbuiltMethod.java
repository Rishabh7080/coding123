package com.nit.array;

import java.util.Arrays;

public class ArrayInbuiltMethod {

	public static void main(String[] args) {
		int arr[]= {2,3,4,6,7};
		        String s=Arrays.toString(arr);
		        System.out.println(s);
		        
		        
		        
		        // writte a program to sort an Array
		        int arr1[]= {5,4,3,6,7};
		                 Arrays.sort(arr1);
		                 String s1=Arrays.toString(arr);
		                 System.out.println(s1);
		                 
		                 
		                 // sort an Array given range
		                 int arr2[]= {5,4,3,6,7};
		                 Arrays.sort(arr2,2,4);// [2 to 4 given Array]
		                 String s2=Arrays.toString(arr2);
		                 System.out.println(s2);
		                 
		                 // copy of range
		                 int arr3[]= {5,4,3,6,7};
		                    int br[] = Arrays.copyOfRange(arr3, 2, 5);
		                 String s3=Arrays.toString(br);
		                 System.out.println(s3);
                     	//
		
		                 
		                 
		                 
		                 
		                 
		                 //replace given range to given
		                 int arrr[]= {5,4,3,6,7};
		                 Arrays.fill(arrr, 2, 5, -8);
		                 String s5=Arrays.toString(arrr);
		                 System.out.println(s5);
                      // compare two array
		                 int ar[]= {10,20,34,45};
		                 int bb[]= {10,20,34,45};
		                 System.out.println(ar.equals(bb));
		                 
	}

}
