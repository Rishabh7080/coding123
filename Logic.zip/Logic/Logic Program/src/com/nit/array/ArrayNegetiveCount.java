package com.nit.array;

import java.util.Scanner;

public class ArrayNegetiveCount {

//	public static void main(String[] args) {
//		int NegativeCount=0;
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the element size:");
//		int n=sc.nextInt();
//		int a[]=new int[n];
//		System.out.println("Enter the element array");
//		for(int i=0;i<n;i++)
//		{
//			a[i]=sc.nextInt();
//		}
//		for(int i=0;i<n;i++)
//		{
//			if(a[i]<0)
//			{
//				 NegativeCount++;
//			}
//		}
//		System.out.println("Count the "+NegativeCount);
//		}
//		
//
//	}

 static void NegativeCount(int a[],int n)
 {
	 int Negativecount=0;

	 for(int i=0;i<n;i++)
	 {
		 if(a[i]<0) {
			 
			Negativecount++;
		 }
	 }
 }
	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the element size");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the element in Array");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		NegativeCount(a,n);
	}
}
