package com.nit.array;

import java.util.Scanner;

public class ArrayNegiveNo {

//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the element::");
//		int n=sc.nextInt();
//		int a[]=new int[n];
//		System.out.println("Enter the element::");
//		for(int i=0;i<n;i++) {
//		                       	a[i]=sc.nextInt();
//		                     }
//		for(int i=0;i<n;i++)
//		{
//			if(a[i]<0)
//			{
//				System.out.println("print the number"+a[i]);
//			}
//			
//		}
//		return;
//
//	}
//}
	public static int NegativeArray(int []a,int n)
	{
		
		for(int i=0;i<n;i++)
		{
			
			if(a[i]<0)
			{
				System.out.println(a[i]);
			}
		}
		return n;
		
	}
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the element::");
		int n=sc.nextInt();
		int []a=new int[n];
		System.out.println("enter the element:");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println(("rev no is :"+NegativeArray(a,n)));
		
				
	}
	}

