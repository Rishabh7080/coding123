package com.nit.array;

import java.util.Scanner;

public class ArrayThinking {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s="Hacker";
		char ar[]=s.toCharArray();
		String t="";
		String v="";
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if(s.indexOf(c)%2==0)
			{
				t=t+c;
			}
			else
			{
				v=v+c;
			}
		}
				
				System.out.print(t+" "+v);
		
	}
}

