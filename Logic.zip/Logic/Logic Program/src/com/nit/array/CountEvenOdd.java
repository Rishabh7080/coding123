package com.nit.array;

import java.util.Scanner;

public class CountEvenOdd {

//	public static void main(String[] args) {
//		int Evencount=0,Oddcount = 0;
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the element:");
//		int n=sc.nextInt();
//		int a[]=new int[n];
//		System.out.println("Enter the element to store the element");
//		for(int i=0;i<n;i++)
//		{
//			a[i]=sc.nextInt();
//		}
//		for(int i=0;i<n;i++)
//		{
//			if(a[i]%2==0)
//			  {
//				Evencount++;
//			  }
//			else {
//				Oddcount++;
//			    }
//		}
//		System.out.println(Evencount);
//		System.out.println(Oddcount);
//		}
//		
//		
//
//	}
//-----------------------------------------------------------------------------------------
	 static void GetCount(int a[],int n)
	{
		int EvenCount=0;
		int OddCount=0;
		for(int i=0;i<n;i++)
		{
			if(a[i]%2==0)
			    EvenCount++;
			else 
			OddCount++;	
		
		  }
		System.out.println("evenCount "+EvenCount);
		System.out.println("oddcout"+OddCount);
		
	 
	  }

	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the element size");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the Array element:");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		GetCount(a,n);
		
	}
}

