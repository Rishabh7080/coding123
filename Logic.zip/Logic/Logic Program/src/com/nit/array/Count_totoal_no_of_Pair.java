package com.nit.array;

public class Count_totoal_no_of_Pair {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5,2,4,3,3,4,2,4,3};
		int c=0;
		int k=5;
		for (int i = 0; i < a.length-2; i++) {
			for (int j = 0; j < a.length; j++) {
				//if(a[i]+a[j]==k)
				if (a[i]+a[j]%k==0) 
				{
					c++;
				}
			}
			
		}
		System.out.println(c);

	}

}
