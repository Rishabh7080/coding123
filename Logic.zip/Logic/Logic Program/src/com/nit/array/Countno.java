package com.nit.array;

class Countno {
	public static void main(String[] args) {
		System.out.println(countNumber(6565));
	}
	static int countNumber(Integer n) {
		if(n==0)
			return 0;
		
		return 1+countNumber(n/10);
	}
//		int n=5455;
//		int c = 0;
//		while(n!=0)
//		{
//			n=n/10;
//		    c++; 
//		}
		//System.out.println(c);
		//}
}


