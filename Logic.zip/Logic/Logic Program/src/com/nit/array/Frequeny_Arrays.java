package com.nit.array;



public class Frequeny_Arrays {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5,2,4,3,3,4,2,4,3};
	
		/*
		int c=1;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if (a[i]==a[j] && a[j]!=0) {
					c++;
					a[j]=0;
				}
			}
			if(a[i]>0)
			   {
			   System.out.println(a[i]+"---"+c);
			   }
*/
		int n=a.length;
		int frq[]=new int[n];
		for (int e:a) {
			frq[e]++;
		}
			for (int i = 0; i < a.length; i++) {
				if (frq[i] > 0) {
					//System.out.printf("%d occure %d times\n", i, frq[i]);
					System.out.println(i+ "--  "+frq[i] );
				}
			}
		}

	}


