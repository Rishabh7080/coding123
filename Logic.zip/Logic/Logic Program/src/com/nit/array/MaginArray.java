package com.nit.array;

import java.util.Arrays;
import java.util.Scanner;

public class MaginArray {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	//System.out.println("enter the Array Size");
	//int n=sc.nextInt();
	//int a[]=new int [n];
	
	
	/*
	 * for (int i = 0; i < a.length; i++) { a[i]=sc.nextInt(); }
	 */
	int a[]= {1,2,3,4,5};
	int sort[]=a.clone();
	Arrays.sort(sort);
	int gd=0,bd=0;
	for (int i = 0; i < sort.length; i++) {
		if(a[i]==sort[i])
			gd+=a[i];
		else 
			bd+=a[i];
	}
		System.out.println(gd-bd);
	}

	}


