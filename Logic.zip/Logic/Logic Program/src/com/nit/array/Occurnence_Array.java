package com.nit.array;

import java.util.Arrays;
import java.util.Scanner;

public class Occurnence_Array {
public static void main(String[] args) {
	/*int a[]= {1,2,3,4,5,2,4,3,3,4,2,4,3};
	System.out.println(Arrays.toString(a));
	Arrays.sort(a);
	System.out.println(Arrays.toString(a));
	String s=new String(Arrays.toString(a));
	*/
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Size of Array");
	int n=sc.nextInt();
	int a[]=new int [n];
	for (int i = 0; i < a.length; i++) {
		a[i]=sc.nextInt();
	}
	Arrays.sort(a);
	String s=Arrays.toString(a);
	System.out.println(s);
	s=s.replaceAll("[, ]","");
	s=s.replace("[", "");
	s=s.replace("]", "");
	System.out.println("After remove break and []");
	 System.out.println(s);
	 while(s.length()>0)
	   {
		 char c=s.charAt(0);
		int occ=s.lastIndexOf(c)+1;
		   System.out.println(s.charAt(0)+"--"+occ);
		s=s.replace(""+c,"");
	   }

			
}
}
