package com.nit.array;

import java.util.Scanner;

public class ReversArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the element:");
		int n=sc.nextInt();
		int a[]=new int [n];
		System.out.print("Enter the Array element::");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
			
		}
		System.out.println("rev array is::");
		for(int i=n-1;i>=0;i--)
		{
			System.out.print("\t"+a[i]);
		}
		//return;
		
		}
		

	}


