package com.nit.array;

import java.util.*;

public class SumOfElement {
  
//	public static void main(String[] args) {
//		int sum=0;
//	Scanner sc=new Scanner(System.in);
//	System.out.println("Enter the element");
//	int n=sc.nextInt();
//	int a[]=new int[n];
//	System.out.println("Enter the no of element:");
//	for(int i=0;i<n;i++)
//	{
//		a[i]=sc.nextInt();
//		
//	//System.out.println(""+a[i]);
//		
//	}
//	for(int i=0;i<n;i++)
//	{
//		
//		 sum =sum+a[i];
//		
//	}
//	System.out.println("sum of\t"+n+"element is\t"+sum);
//	
//	}
//
//}
	//----------------------------------------------------------------------------------------------------------
	public static int SumOf(int []a,int n) {
      int sum=0;
		for(int i=0;i<n;i++)
		{
			sum=sum+a[i];
		}
		return sum;
		
	  }

	
	

public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the array Size:");
		int n=sc.nextInt();
		int a[]=new int [n];
		System.out.println("Enter the element to stor the Array");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println(("sum of element"+SumOf(a,n)));
		}
	}

