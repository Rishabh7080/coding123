package com.nit.logic;

import java.util.Scanner;

public class BinaryThinkin {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int  n=5;
		
		String s=Integer.toBinaryString(n);
		String t="";
		for(int i=0;i<s.length();i++)
		{
			t=t+s.charAt(i);
			
		}System.out.println(t);
		}

	}


