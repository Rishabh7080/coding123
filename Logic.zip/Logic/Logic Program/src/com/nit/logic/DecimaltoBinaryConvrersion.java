package com.nit.logic;

import java.util.Scanner;

public class DecimaltoBinaryConvrersion {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Numbr:");
		int n=sc.nextInt();
//************PRE DEFIND METHOD*********
		/*   String str= Integer.toBinaryString(n);
		   System.out.println(str);
		   */
 
//****using logic**********		
		
	       int rem[]=new int[20];
	       int i=0;
	       while(n>0)
	       {
	    	   rem[i]=n%2;
	    	   i++;
	    	   
	    	   n=n/2;
	       }
	       for(int j=(i-1);j>=0;j--)
	       System.out.print(rem[j]);
	       }
	       
		     

	}


