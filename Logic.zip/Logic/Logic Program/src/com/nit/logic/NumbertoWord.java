package com.nit.logic;

import java.util.Scanner;

public class NumbertoWord {
public String one_to_hand(int n)
{
	String str=" ";
	while(n!=0)
	{
		if(n==1) {
			str=str+"one";
					n=0;
		}
		else if(n==2) {
			str=str+"two";
					n=0;
		}
		else if(n==3) {
			str=str+"three";
					n=0;
		}
		 else if(n==4) {
			str=str+"four";
					n=0;
		}
		 else if(n==5) {
			str=str+"five";
					n=0;
		}
		 else if(n==6) {
			str=str+"six";
					n=0;
		}
		 else if(n==7) {
			str=str+"seven";
					n=0;
		}
		 else if(n==8) {
			str=str+"eight";
					n=0;
		}
		 else if(n==9) {
			str=str+"nine";
					n=0;
		}
		 else if(n==10) {
			str=str+"ten";
					n=0;
		}
		 else if(n==11) {
			str=str+"eleven";
					n=0;
		}
		 else if(n==12) {
			str=str+"twelth";
					n=0;
		}
		 else if(n==13) {
			str=str+"thirteen";
					n=0;
		}
		 else if(n==14) {
			str=str+"fourteen";
					n=0;
		}
		 else if(n==15) {
			str=str+"fifteen";
					n=0;
		}
		 else if(n==16) {
			str=str+"sixteen";
					n=0;
		}
		 else if(n==17) {
			str=str+"sevrnteen";
					n=0;
		}
		 else if(n==18) {
			str=str+"eighteen";
					n=0;
		}
		 else if(n==19) {
			str=str+"ninteen";
					n=0;
		}
		 else if(n>=20 && n<30) {
			str=str+"twenty";
					n-=20;;
		}
		 else if(n>=20 && n<40) {
				str=str+"thirty";
						n-=30;;
			}
		 else if(n>=40 && n<50) {
				str=str+"fourty";
						n-=40;;
			}
		 else if(n>=50 && n<60) {
				str=str+"fifty";
						n-=50;;
			}
		 else if(n>=60 && n<70) {
				str=str+"sixty";
						n-=60;;
			}
		 else if(n>=70 && n<80) {
				str=str+"seventy";
						n-=70;;
			}
		 else if(n>=80 && n<90) {
				str=str+"eighty";
						n-=80;;
			}
		 else if(n>=90 && n<100) {
				str=str+"ninty";
						n-=90;;
			}
		}
	return str;
	}

public String conver(int m)
{
	String str=" ";
	while(m!=0)
	{
		if(m>=1&&m<100)
		{
			str+=one_to_hand(m);
			m=0;
		}else if(m>=100&& m<1000)
		{
			str+=one_to_hand(m/100);
			str+="Hundred";
			m%=100;		
			}
		else if(m>=1000 && m<10000)
		{
			str+=one_to_hand(m/1000);
			str+="thosand";
			m%=1000;
		}
	}

return str;

}

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
      System.out.println("Enter the number");
      int n=sc.nextInt();
      NumbertoWord obj=new NumbertoWord();
     System.out.println( obj.one_to_hand(n));
      
	}

}
