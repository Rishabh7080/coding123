package com.nit1;

public class Joker {

	public static void main(String[] args) {
		int n=9;
		for (int i = 0; i < n; i++) {// first for loop
			for (int j = 0; j < n; j++)
			{
				System.out.print(" ");
			}
			for (int j = 0; j < n; j++) {
				if(j>=n/2-i&&j<=n/2+i&&i<=n/2||j>=n/4&&j<=3*n/4&&j>=i-n/2&&j<=n+n/2-1-i&&i>=n/2)
				System.out.print("*");
				else
					System.out.print(" ");	
			}System.out.println();
		}
			for (int i = 0; i < n; i++)
			{                                   //second loop
			for (int j = 0; j < n; j++) 
			{
				//System.out.print(" ");
				if(j>=n-1-i&&j<=n+n/2-1-i||j>=n/2+i)
					System.out.print("*");
				else
					System.out.print(" ");
				
			}
			for (int j = 0; j < n; j++) {
				if(j<=i||j>=n-1-i)
				System.out.print("*");
				else
					System.out.print(" ");
				
			}
			for (int j = 0; j < n; j++) {
				if(j<=i&&j>=i-n/2||j<=n/2-i)
				System.out.print("*");
				else
					System.out.print(" ");
				
			}
			System.out.println();
			}
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
//					if(j>=n+n/2-1-i)
//					System.out.print("* ");
//					else
						System.out.print(" ");
					
				}
				for (int j = 0; j < n; j++) {
					if(j==0||j==1||j==n-1||j==n-2)
					System.out.print("*");
					else
						System.out.print(" ");
					
				}
				System.out.println();
				
			}
		}

	}



