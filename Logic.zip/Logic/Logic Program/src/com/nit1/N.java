package com.nit1;

import java.util.Scanner;

public class N {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the elemenmt:");
		int n=sc.nextInt();
		for (int i = 1; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if(j==0||j==n-1||j==i)
				{
					System.out.print("*");
				}
				else
					System.out.print(" ");
			}
			System.out.println();
			}
			
		}

}
