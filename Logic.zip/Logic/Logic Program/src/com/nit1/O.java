package com.nit1;

import java.util.Scanner;

public class O {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the elemenmt:");
		int n=10;
		//int n=sc.nextInt();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if((j==0||j==n-1)&&(i!=0&&i!=6)||i==0)
				{
					System.out.print("*");
				}
				else
					System.out.print(" ");
	  		}
			System.out.println();
			}
			
		}

}
