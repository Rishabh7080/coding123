package com.nit1;

import java.util.Scanner;

public class PatternProgram {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("ENter the element size ");
	int n=sc.nextInt();
	for(int i=n;i<=n;i++) {
		for(int j=n;j<=n;j++)
		{
		if(i==n)
			System.out.print(i);
		else
			System.out.print(" ");
		}
		System.out.println();
	}
		

	}

}
