package com.nit1;

public class RISHABH {

	public static void main(String[] args) {
		int  n=12;
		for(int i=0;i<n;i++) {
			for(int j=0;j<4;j++)
			{
				if(j==0||j==i+1||i+j==7||i*j==i+j+3)
				{
					System.out.print("*");
				}
				
				else 
					System.out.print(" ");
				}
			
			System.out.print("  ");
			
			
			for (int j = 0; j < 4; j++) {
				if(j==0||j==i+1||i+j==7||i*j==i+j+3||j==i-n/2)
					System.out.print("*");
				else
					System.out.print(" ");
				}
			 System.out.print("  ");
			 
			 
			for (int j = 0; j < n; j++) {
				if(i==0||j==n/2||i==n-1)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.print("  ");
			
			
				for (int j = 0; j < n; j++) {
					if(i==0||j==n/2)
					System.out.print("*");
					else
						System.out.print(" ");
				}
				System.out.print("  ");
				for (int j = 0; j < n; j++) {
					if(j==i&&i<=5||j==n-1-i)
					System.out.print("*");
					else
						System.out.print(" ");
				}
			System.out.print("  ");
						
		
		System.out.println();
		       
		}
		}
	 
	}
