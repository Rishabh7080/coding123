package com.nit1;

public class Rocket {

	public static void main(String[] args) {
	int n=7;
	for (int i = 0; i < n; i++) {// first loop
		for (int j = 0; j < n; j++) {
			System.out.print(" ");
			
		}
		for (int j = 0; j < n; j++) {
			if(j>=n/2-i&&j<=n/2+i)
				System.out.print("*");
			else
				System.out.print(" ");
			
		}System.out.println();
		
	}
	for (int i = 0; i < n; i++)// secound loop
	{
		for (int j = 0; j < n; j++)
		{
	     	System.out.print(" ");
		}
		for (int j = 0; j < n; j++) {
			
				System.out.print("*");
		}
		System.out.println();
}
		for (int i = 0; i < n; i++) {// third loop
			
	for (int j = 0; j < n; j++) {
		if(j>=n-1-i)
		System.out.print("*");
		else
			System.out.print(" ");
		}
	for (int j = 0; j < n; j++) {
		
			System.out.print("*");
	}
	for (int j = 0; j < n; j++) {
		if(j<=i)
		System.out.print("*");
		else
			System.out.print(" ");
		
	}
	System.out.println();
}
}
}



