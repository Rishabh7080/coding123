package com.nit1;

import java.util.Scanner;

public class Twinkl {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the element no");
	//int n=sc.nextInt();
	int  n=10;
	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++)
		{
			if(i==0||j==n/2-3)
			{
				System.out.print("*");
			}
			
			else 
				System.out.print(" ");
			}
		System.out.print("  ");
		for (int j = 0; j < n; j++) {
			if(j==0||j==n-1||(j==i||j==n-1-i)&&i>3)
				System.out.print("*");
			else
				System.out.print(" ");
			}
		 System.out.print("  ");
		for (int j = 0; j < n; j++) {
			if(i==0||j==n/2||i==n-1)
				System.out.print("*");
			else
				System.out.print(" ");
		}
		System.out.print("  ");
			for (int j = 0; j < n; j++) {
				if(j==0||j==n-1||j==i)
				System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.print("  ");
			for (int j = 0; j < n; j++) {
				if(j==0||j==n/2-i||j==i-n/2)
				System.out.print("*");
				else
					System.out.print(" ");
			}
		System.out.print("  ");
		for (int j = 0; j < n; j++) {
			if(j==0||i==n-1)
			System.out.print("*");
			else
				System.out.print(" ");
		}
	System.out.print("  ");
	for (int j = 0; j < n; j++) {
		if(j==0||i==n-1||i==0||i==n/2)
		System.out.print("*");
		else
			System.out.print(" ");
	}
System.out.print("  ");

	
		
	
	System.out.println();
	       
	}
	}
 
}
