package com.nt.ifelse;

public class Test2 {
 
	public static void main(String[] args) 
			{ 
				int j = 0; 
				do 
					for (int i = 0; i++ < 1;) 
						System.out.println(i); 
				
				while (j++ < 2); 
			} 
		} 



