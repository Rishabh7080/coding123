package com.test;
import java.util.*;

public class Country {
	/** Main method */
	public static void main(String[] args) {	
		// Create a scanner
		Scanner input = new Scanner(System.in);

		// Store 50 states and their capitals
		Map<String, String> statesAndCapitals = getData();

		// Prompt the user to enter a state
			System.out.print("Enter a country: ");
			String state = input.nextLine();
	
		// Display the capital for the state
		if (statesAndCapitals.get(state) != null) {
			System.out.println("The capital of " + state + " is " 
				+ statesAndCapitals.get(state));
		}
	}

	/** Method getData stores the 50 states and their capitals in a map */
	public static Map<String, String> getData() {
		Map<String, String> map = new HashMap<>();
		String[][] data = {
			{"India", "delhi"}, {"pakistan", "Islamabad"}, {"Australia", "CanBerra"}};
			

		for (int i = 0; i < data.length; i++) {
			map.put(data[i][0], data[i][1]);
		}

		return map;
	}
}