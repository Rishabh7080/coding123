package com.test;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		Random r = new Random();

		Scanner input = new Scanner(System.in);

		String[] capital = { "Lisbon", "Madrid", "Paris", "Berlin", "Warsaw", "Kiev", "Moscow", "Prague", "Rome" };
		String[] country = { "Portugal", "Spain", "France", "Germany", "Poland", "Ukraine", "Russia", "Czech Republic",
				"Italy" };
		Boolean[] was = new Boolean[9];

		int score = 0;
		int good = 0;
		int bad = 0;

		File file = new File("score.txt");
		Scanner lastscoreopener = new Scanner(file);
		String lastscore = lastscoreopener.nextLine();
		System.out.print("Your last score was: " + lastscore + "\n");

		for (int d = 1; d < 4; d++) {
			int randomint = r.nextInt(9);
			while (was[randomint] == Boolean.FALSE) {
				randomint = r.nextInt(9);
			}
			was[randomint] = false;

			while (was[randomint] == true)
				;
			for (int x = 0; x < 3; x++) {
				System.out.print("What's capital of " + country[randomint] + "\n");
				String answer = input.nextLine();
				if (answer.toLowerCase().equals(capital[randomint].toLowerCase())) {
					if (x == 0) {
						score = score + 3;
						good++;
					} else if (x == 1) {
						score = score + 2;
						good++;
					} else if (x == 2) {
						score = score + 1;
						good++;
					}
					System.out.print("Good. Your score is" + score + ". \n");
					break;
				} else {
					if (x != 2) {
						System.out.print("Bad. You have " + (2 - x) + " chances. ");
					}
					if (x == 2) {
						System.out.print("Bad. Good answer is" + capital[randomint] + "\n");
					}
					bad++;
				}
			}
		}
		System.out.print("End of game. Good answers:" + good + ". Bad answers: " + bad + ". Score: " + score);

		PrintWriter saver = new PrintWriter("score.txt");
		saver.println(score);
		saver.close();

	}
}
