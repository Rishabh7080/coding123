package com.test;
import java.util.*;
class program1
{
   public static void main(String []args)
   {    
  String s="smckjd";
  for (int i = 0; i < s.length(); i++) {
	char c=s.charAt(i);
}
   }
}

