package info.pattern;

public class N0Pattern15 {

	public static void main(String[] args) {
		int n=7;
		int c=1;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (j<=i) {
					
					System.out.print(i+c++ +" ");
				}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
			
		}

	}


