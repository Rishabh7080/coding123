package info.pattern;

public class No1Pattern27 {

	public static void main(String[] args) {
		int n=5;
		 for (int i=0;i<n ;i++ )

		 {
			 for (int j=0;j<n;j++)
			 {
				 if(j==0||i==n-1||j==i)
				 {
					 System.out.print("1");
				 }
				 else if(j>=i)
				 {
					 System.out.print(" ");
				 }
				else
				 {
	             System.out.print("0");
				 }
			 }
//			 1    a
//			 11   
//			 101  
//			 1001 
//			 11111

			 
			
			  System.out.println();
			  
		 }
	   }
	 }
	   
