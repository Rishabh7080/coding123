package info.pattern;

public class NoPattern1 {

	public static void main(String[] args) {
		int n=5;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				//System.out.print(i);
//				00000
//				11111
//				22222
//				33333
//				44444
				
				//System.out.print(j);
//				01234
//				01234
//				01234
//				01234
				
				
//				if(i%2==0)
//				{
//					System.out.print(0);
//				}
//				else
//				{
//					System.out.print(1);
//				}
//				00000
//				11111
//				00000
//				11111
//				00000
				
				
				
				
//				System.out.print(i+1);
//				11111
//				22222
//				33333
//				44444
//				55555
//				
//				System.out.print(j+1);
//				12345
//				12345
//				12345
//				12345
//				12345
//				
				
				
//				if(j% 2==0&&i%2==0||i==j||j==n-1-i)
//					{
//						System.out.print(0);
//					}
//					else
//					{
//						System.out.print(1);
//					}
//				
//				01010
//				10101
//				01010
//				10101
//				01010
//				
//				if(i==j)
//				{
//					System.out.print(i);
//				}
//				else
//				{
//					System.out.print(0);
//				}
//				
//				00000
//				01000
//				00200
//				00030
//				00004
				
				
				
//				if(i==0||i==n-1||j==0||j==n-1)
//				{
//					System.out.print(1);
//				}
//				else
//				{
//					System.out.print(0);
//				}
//				11111
//				10001
//				10001
//				10001
//				11111
				
				
//				if(i%2==1)	
//				{
//				System.out.print(0);
//				}
//			else
//				{
//						System.out.print(1);
//				 }
//			    11111
//				00000
//				11111
//				00000
//				11111
				
				
//				
//   System.out.print((i+1)%2);
//   
//   11111
//   00000
//   11111
//   00000
  // 11111
//				System.out.print((i+j+1)%2);
//				10101
//				01010
//				10101
//				01010
//				10101


			}
			System.out.println();
		}
	}

}
