package info.pattern;

public class NoPattern16 {

	public static void main(String[] args) {
		int n=5;
		for (int i = 0; i <n; i++) {
			for (int j = 0; j < n; j++) {
				
//				System.out.print((char)(i+65));
//				AAAAA
//				BBBBB
//				CCCCC
//				DDDDD
//				EEEEE
				
//				if(j<=i)
//				{
//					System.out.print((char)(i+65));
//				}
//				else
//				{
//					System.out.print(" ");
//				}
//
//				
//			}
//			System.out.println();
//			
//			//A    
//			BB   
//			CCC  
//			DDDD 
//			EEEEE

		}

	}

}
}
