package info.pattern;

public class NoPattern17 {

	public static void main(String[] args) {
		int n=5;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
//				if(j<=n-1-i)
//				{
//					System.out.print((n-1-i)-j);
//				}
//				else
//				{
//					System.out.print(" ");
//				}
//				
//				43210
//				3210 
//				210  
//				10   
//				0    
				
//			if(j<=i)
//			{
//				System.out.print(i-j);
//			}
//			else
//			{
//				System.out.print(" ");
//			}
//			0     
//			10    
//			210   
//			3210  
//			43210 
				if(j>=n-1-i)
				{
					System.out.print(j-(n-1-i));
				}
				else
				{
					System.out.print(" ");
				}

            
				
			}System.out.println(" ");
			
		}System.out.println();
	}

}
