package info.pattern;

public class NoPattern19 {

	public static void main(String[] args) {
      int n=5;
      for (int i = 0; i < n; i++) {
    	  for (int j = 0; j < n; j++) {
    		  if(j<=i)
    		  {
    			  System.out.print(j+1);
    		  }
    		     	  }
    		  for (int j = 1; j < n; j++) {
    			  if(j<=i) {
        			  System.out.print(i-j+1);

    			  }
    			  else
    			  {
        			  System.out.print(" ");

    			  }
				
		
			
		}System.out.println();
		
	}
	}

}
