package info.pattern;

public class NoPattern21 {

	public static void main(String[] args) {
	int n=5;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j <n; j++) {
//			if (j>=i) {
//				System.out.print(j);
//			}
//			else
//			{
//				System.out.print(" ");
//			}
//		}
//		for (int j = 1; j <n; j++) {
//			if (j<=n-1-i) {
//				System.out.print(n-1-j);
//			}
//			else
//			{
//				System.out.print(" ");
//			}
//			
//			012343210
//			 1234321 
//			  23432  
//			   343   
//			    4    
			
			
			if (j>=i) {
				System.out.print((char)(65+j));
			}
			else
			{
				System.out.print(" ");
			}
		}
		for (int j = 1; j <n; j++) {
			if (j<=n-1-i) {
				System.out.print((char)(65+n-1-j));
			}
			else
			{
				System.out.print(" ");
			}
			
			

			
//			ABCDEDCBA
//			 BCDEDCB 
//			  CDEDC  
//			   DED   
//			    E    

			
			
			
			
			
			
			
			
			
			
		}
		System.out.println();
	}

	}

}
