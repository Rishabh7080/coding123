package info.pattern;

public class NoPattern22 {

	public static void main(String[] args) {
		int n =5;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
					if(j<=n-1-i)
				{
					System.out.print(i+j);
				}
//				01234
//				1234
//				234
//				34
//				4
				
				
				if (j<=n-1-i) {
					System.out.print(j-(n-1-i)+n-1);
					
				}
//				01234
//				1234
//				234
//				34
//				4


				
			}System.out.println();
			
		}
	}

}
