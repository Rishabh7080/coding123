package info.pattern;

public class NoPattern25 {

	public static void main(String[] args) {
		int n=7;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
			/*	if(j>=n-1-i) {
				System.out.print("* ");
		          	}
			  else
				{
				System.out.print(" ");
				}
			}
			
			
			
			 * 
		     * * 
		    * * * 
		   * * * * 
		  * * * * * 
		 * * * * * * 
		* * * * * * * 
			*/

				
				
			if(j>=n-1-i)
			{
				if(j==n-1||j==n-1-i||i==n-1) {
				System.out.print("1 ");
				}
				else
				{
					System.out.print("0 ");
				}
				
			}
			else
			{
				System.out.print(" ");
			}
			}
				/*     
				 * 
	  1 
     1 1 
    1 0 1 
   1 0 0 1 
  1 0 0 0 1 
 1 0 0 0 0 1 
1 1 1 1 1 1 1 

				*/
				
				
				
				
			
			
			
			System.out.println();
		}

	}

}
