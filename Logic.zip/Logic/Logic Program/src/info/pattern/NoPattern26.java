package info.pattern;

public class NoPattern26 {

	public static void main(String[] args) {
		int n=7;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (j<=n-1-i) {
					System.out.print(i+j);
					
				}
			}
			for (int j = 1; j < n; j++) {
				if(j<=n-1-i)
				{
					System.out.print(n-1-j);
				}
				
			}
				
				System.out.println();
			}
			

	}

}
