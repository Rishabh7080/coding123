package info.pattern;

public class NoPattern27 {

	public static void main(String[] args) {
		int n=5;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (j>=n-1-i)
				    {
					System.out.print(n-j);
					}
				else
				{
					System.out.print(" ");
				}
				}
			for (int j = 1; j < n; j++) {
				if(j<=i)
				{
					System.out.print(j+1);
				}
				else
				{
					System.out.print(" ");
				}
			}
			
			System.out.println();
			}
		for (int i = 1; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (j>=i)
				    {
					System.out.print(n-j);
					}
				else
				{
					System.out.print(" ");
				}
				}
			for (int j = 1; j < n; j++) {
				if(j<=n-1-i)
				{
					System.out.print(j+1);
				}
				else
				{
					System.out.print(" ");
				}
			}
			
			System.out.println();
	}
			
		}                        
//	   212   
//	   32123  
//	  4321234 
//	 543212345
//	  4321234 
//	   32123  
//	    212   
//	     1    

}
	

	

