package info.pattern;

public class NoPattern29 {

	public static void main(String[] args) {
		int n=11;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (j>=i&&j<=n-1-i)
				{
					System.out.print(i);
				}
				
				else if(j<=i&&j<=n-1-i)
				{
					System.out.print(j);
				}
				else if(j>=i&&j>=n-1-i)
				{
					System.out.print(n-1-j);
				}
				else if(j>n-1-i&&j<=i)
				{
					System.out.print(n-1-i);
				}
				
				
			}
			System.out.println();
		}

	}

}
