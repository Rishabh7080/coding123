package info.pattern;

public class NoPattern3 {

	public static void main(String[] args) {
		int n=5; for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
//				if(j<=i)
//				{
//					System.out.print(i);
//				}
//				else
//					System.out.print(" ");
//				
//				0    
//				11   
//				222  
//				3333 
//				44444
				
//				if(j>=n-1-i)
//				{
//					System.out.print(n-1-j);
//				}
//				else
//					System.out.print(" ");
//				
//			     0
//			    10
//			   210
//			  3210
//			 43210

				
				
				
				

			}
			System.out.println();
		}

		
		
		
	}

}
