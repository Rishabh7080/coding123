package info.pattern;

public class NoPattern30 {

	public static void main(String[] args) {
		int n=5;
		int c=1;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j <n; j++) {
				if (j<=i) {
					//System.out.print(c+" ");
					System.out.printf("%02d ",c);
					
					c++;
				}
				else
				{
					System.out.print(" ");
				}
				
			}
			System.out.println();
		}

	}

}
