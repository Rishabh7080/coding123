package info.pattern;

public class NoPattern31 {

	public static void main(String[] args) {
		int n=5;
		/*for (int i = 0; i < n; i++) {
			int c=i+1;
			for (int j = 0; j < n; j++) {
				if(j<=i) {
				//System.out.print(c+" ");
					System.out.printf("%02d ",c);
				
				c+=n;
				}
			}
			System.out.println();
		}*/
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if(j<=i)
				System.out.print(i+1+n*j+" ");
			}
			System.out.println();
		}
		
		
		
		
		
		

	}

}
