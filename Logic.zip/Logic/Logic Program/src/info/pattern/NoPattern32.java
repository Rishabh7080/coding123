package info.pattern;

public class NoPattern32 {

	public static void main(String[] args) {
		int n=5;
		for (int i = 0; i < n; i++) {
			int m=i+1;
			int sn=m*(m+1)/2;
			for (int j = 0; j < n; j++) {
				if(j<=i)
				System.out.print(sn-j+" ");
				
			}
			System.out.println();
		}

	}

}
