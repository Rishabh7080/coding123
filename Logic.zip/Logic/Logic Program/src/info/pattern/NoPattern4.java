package info.pattern;

public class NoPattern4 {

	public static void main(String[] args) {
		int n=5;
		for (int i = 1; i < n; i++)// 1stLoop
		{
			for (int j = 0; j < n; j++) 
			{
				if(j<=n-1-i)
				{
					System.out.print(j+1);
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
			}
		for (int i = 1; i < n; i++)// 1stLoop
		{
			for (int j = 0; j < n; j++) 
			{
				if(j<=i) {
					System.out.print(j+1);
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();

	}
	}
}


//1234 
//123  
//12   
//1    
//12   
//123  
//1234 
//12345


