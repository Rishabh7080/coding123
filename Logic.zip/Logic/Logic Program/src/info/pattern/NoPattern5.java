package info.pattern;

public class NoPattern5 {

	public static void main(String[] args) {
		int n=5;
		for (int i = 0; i < n; i++)// 1stLoop
		{
			for (int j = 0; j < n; j++) 
			{
				if(j>=n-1-i)
				{
					System.out.print(j);
				}
				else
				{
					System.out.print(" ");
				}
			}
			for (int j = 1; j < n; j++) {//2nd lop
				if(j<=i)
				{
					System.out.print(n-1-j);
				}
				else
				{
					System.out.print(" ");
				}
			}
         System.out.println();
	}
	}

}                    
                         

