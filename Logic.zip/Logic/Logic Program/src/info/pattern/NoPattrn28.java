package info.pattern;

public class NoPattrn28 {

	public static void main(String[] args) {
          int n=6;
		   for (int i = 0; i < n; i++) 
		   {
			   for (int j = 0; j < n; j++)
               {
				  if (j==n-1-i)
				  {
					System.out.print((char)(65+i));
				   }
			     else
				  {
					  System.out.print(" ");
				  }
				  
				
			   }
			   for (int j = 1; j < n; j++) {			
				   if (j==i) {
			   
					System.out.print((char)(65+i));
				   }
				else
				{
					System.out.print(" ");
				}
				
			}
			System.out.println();
		}
		   for (int i = 1; i < n; i++) 		   {
			   for (int j = 0; j < n; j++)
			   {
				  if (j==i)
				  {
				System.out.print((char)(65+n-1-j));
				   }
				  else
				  {
					  System.out.print(" ");
				  }
			   }
				
			   
			   for (int j = 1; j < n; j++) {
				   if (j==n-1-i) 
				   {
					System.out.print((char)(65+j));
				}else
				{
					System.out.print(" ");
				}
				
			}
		System.out.println();
}

}

				   
		/*		   if (j>=n/2-i&&j<=n/2+i&&j<=n+n/2-1-i&&j>=i-n/2)
				   {
					   if (j<=n/2)
					   {   
						   System.out.print(n/2-j);
					   }
					   else 
					   {
						 System.out.print(j-n/2);  
					   }
				   }
				   else
				   {
					  System.out.print(" "); 
				   }
					
				}
		   System.out.println();
	}
*/
}
				   
				   
