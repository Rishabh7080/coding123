package info.string;

import java.util.Scanner;



public class CammalCount {
	public static void main(String[] args) {
		
	
	String s="RisjsnjJDNJSN";
	
      
      int count=0;
	for (int i = 0; i < s.length(); i++) {
		 char c=s.charAt(i);
		 if (c>=65&&c<=90) {
			count++;
		}
	}
	 System.out.println(count);

	
	
		
	}			
			}
			













