

package info.string;

public class Count {

	public static void main(String[] args) {
		String s="ajksncjkb    !*(@W!*#39192w21-9";
		int upcont=0,spacialcont=0,spacecont=0,low=0,numbercnt=0;
		for(int i=0;i<s.length();i++)
		{ char c=s.charAt(i);
			if(Character.isLetter(c))
			{
				if(c>=65&&c<=90)				{
					upcont++;
				}
				else
				{
					low++;
				}
			}
			else if(c>=48&&c<=57)
			{
				numbercnt++;
				
			}
			else if(c==' ')
			{
				spacecont++;
			}
			else
			{
				spacialcont++;	
			}
		  }
		System.out.println("count no"+upcont);
		System.out.println("count no"+low);
		System.out.println("count no"+numbercnt);
		System.out.println("count no"+spacecont);
		System.out.println("count no"+spacialcont);
		}


	}


