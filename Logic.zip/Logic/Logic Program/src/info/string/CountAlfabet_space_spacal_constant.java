package info.string;

public class CountAlfabet_space_spacal_constant {

	public static void main(String[] args) {
		String s="ajksncjkb    !*(@W!*#39192w21-9";
		int vovCont=0,spacialcont=0,spacecont=0,consonent=0,numbercnt=0;
		for(int i=0;i<s.length();i++)
		{ char c=s.charAt(i);
			if(Character.isLetter(c))
			{
				if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U')
				{
					vovCont++;
				}
				else
				{
					consonent++;
				}
			}
			else if(c>=48&&c<=57)
			{
				numbercnt++;
				
			}
			else if(c==' ')
			{
				spacecont++;
			}
			else
			{
				spacialcont++;	
			}
		  }
		System.out.println("count no"+vovCont);
		System.out.println("count no"+consonent);
		System.out.println("count no"+numbercnt);
		System.out.println("count no"+spacecont);
		System.out.println("count no"+spacialcont);
		}


	}


