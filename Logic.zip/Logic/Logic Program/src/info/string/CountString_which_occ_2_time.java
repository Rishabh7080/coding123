package info.string;

import java.util.Arrays;

public class CountString_which_occ_2_time {

	public static void main(String[] args) {
		String s="abasjbsdhcbhwecbhb";
		 char ch[]=s.toCharArray();
		     Arrays.sort(ch);
		     s=new String(ch);
		     int c=1;
		     for (int i = 0; i < s.length()-1; i++) {
		    	 if (s.charAt(i)==s.charAt(i+1)) {
					c++;
				}
		    	 else
		    	 {
		    		 if(c==2) {
		    		 System.out.println(""+s.charAt(i)+c);
		    		 }
		    		 c=1;
		    	 }
		    	 }
		     if(c==2)
		     System.out.println(""+s.charAt(s.length()-1));
				
			}

	
}
