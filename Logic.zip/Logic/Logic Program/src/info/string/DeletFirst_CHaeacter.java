package info.string;

public class DeletFirst_CHaeacter {

	public static void main(String[] args) {
		String s="Rishabh";
		s=s.substring(1);
		System.out.println(s);

	}

}
