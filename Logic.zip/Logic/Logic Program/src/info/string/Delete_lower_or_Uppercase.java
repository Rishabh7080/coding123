package info.string;

public class Delete_lower_or_Uppercase {
public static void main(String[] args) {
	String s="jbhacs873qw!*@^&*";
	String t="";
	for(int i=0;i<s.length();i++)
		
	{
		char c=s.charAt(i);
	     if(c>='A'&&c<='Z'||c>='a'&&c<='z')
		//if(Character.isLetter(c))
		{
			
		}
		else
		{
			t=t+c;
		}
	}
	System.out.println(t);
}
}
