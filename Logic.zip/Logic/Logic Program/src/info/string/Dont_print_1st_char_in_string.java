package info.string;

public class Dont_print_1st_char_in_string {
public static void main(String[] args) {
	String s="habchjzb";
	   s=s.substring(1);
	   System.out.println(s);
}
}
