package info.string;

public class EvenLenthOfString {

	public static void main(String[] args) {
		String s="I love you dear with you marry me";
		for (String word : s.split(" ")) 
			  
            // if length is even 
            if (word.length() % 2 == 0) 
  
                // Print the word 
                System.out.println(word); 
    } 
  
		

	}


