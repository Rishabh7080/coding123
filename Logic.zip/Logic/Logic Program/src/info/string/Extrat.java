package info.string;

public class Extrat {

	public static void main(String[] args) {
		
		 
		
		 }
     
}
