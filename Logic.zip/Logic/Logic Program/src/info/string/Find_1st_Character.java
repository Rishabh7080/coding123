package info.string;

public class Find_1st_Character {

	public static void main(String[] args) {
		String s="abcd";
		     System.out.println(s.charAt(0));
	

	
	}

}
