package info.string;

public class Find_First_Ocuerence {

	public static void main(String[] args) {
		String s="SILLYSPIDERS";
		for (int i = 0; i < s.length(); i++) {
			char c=s.charAt(i);
			if (s.indexOf(c)==s.lastIndexOf(c)) {
				
				System.out.print(c);
			}
			
			
		}

	}

}
