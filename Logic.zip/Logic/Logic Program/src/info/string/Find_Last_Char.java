package info.string;

public class Find_Last_Char {

	public static void main(String[] args) {
		String s="abcd";
//		        int lastIndex=s.length()-1;
//		        System.out.println(s.charAt(lastIndex));
		 for (int i = 0; i <s.length();i++) {
			
		
       System.out.println(s.charAt(i));
  

	}
	}

}
