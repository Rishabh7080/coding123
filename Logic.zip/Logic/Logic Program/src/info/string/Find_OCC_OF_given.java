package info.string;

import java.util.Arrays;

public class Find_OCC_OF_given {
	public static void main(String[] args) {
		
	
	String s="aaabbcccccdfjf";
	      char ar[]=s.toCharArray();
	      Arrays.sort(ar);
	      s=new String(ar);
	    String occcount="";
	      while(s.length()>0)
	     {
	    	 char c=s.charAt(0);
	    	 int occ=s.lastIndexOf(c)+1;
	    	 if(occ==2) {
	    		 occcount=occcount+c;
	    		
	    	 }
	    	
	    	
	    	s=s.replace(""+c,"");
	     }
	System.out.println(occcount+"");
	
	
}
}
