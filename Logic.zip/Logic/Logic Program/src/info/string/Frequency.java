package info.string;



public class Frequency {

	public static void main(String[] args) {

		String s="aaaaabbbccccccddddeee";
		for (int i = 0; i<s.length(); ) {
			char c=s.charAt(i);
			int occ=s.lastIndexOf(c)-s.indexOf(c)+1;
			System.out.println(""+c+"  "+occ);
			i=s.lastIndexOf(c)+1;
			
		}
		
	}
}
