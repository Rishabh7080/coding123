package info.string;
import java.util.*;
import java.lang.*;
import java.io.*;

import java.util.Scanner;

public class GeeksForGeeksConvertTOLower_case {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	   int N=sc.nextInt();
	   for (int i = 0;i<N; i++) {
		   String s=sc.next();
		   s=s.toLowerCase();
		
	}
	
}
}
