package info.string;

public class Hackerran_lavel_thinking {
	public static void main(String[] args) {
		
	
// input -aPPle
	//output-Apple
	String s="aPPle";
	     String sf=s.substring(1);
	     sf=sf.toLowerCase();
	     String fs=""+s.charAt(0);
	             fs=fs.toUpperCase();
;	     
	  System.out.println(fs+sf);
		}
}
