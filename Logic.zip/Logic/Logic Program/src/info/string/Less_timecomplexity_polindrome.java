package info.string;

public class Less_timecomplexity_polindrome {

	public static void main(String[] args) {
		String s="abcjba";
		int slap=0;
		for (int li=0,hi=s.length()-1;li <hi;li++,hi--) {
			if (s.charAt(li)==s.charAt(hi)) {
				
			       }
			else {
				slap++;
			break;
			}
				
			
		}
		
		if (slap==0) 
			System.out.println("polindrome");
			else
				System.out.println("not polindrome");
			
}
	}


