package info.string;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Minimum_chrange_SubString_distinct {

	public static void main(String[] args) throws IOException {
		
	try
	{
		testException();
		
	}
	catch(FileNotFoundException e)
	{
		System.out.println("ehgf"+e);
	}
	}

	private static void testException() throws  IOException,FileNotFoundException

	
	{
		System.out.println("hi alixa");
		
	}
}
