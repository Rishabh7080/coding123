package info.string;

public class Panagram {
	public static void main(String[] args) {
		//String s="abcdefghijklmnopqrstvywxz";
	//	String s="fdljjfdvf";
		String s="The brown fox jumps over the dog";
		s=s.replace(" ", "");
		s=s.toUpperCase();
		int c=0;
		for(char i=0;i<s.length();i++)
		{
			if(s.contains(""+i))
			{
				c++;
			}
		}
		if(c==26)
			System.out.println("panagram");
		else
		{
			System.out.println("Not panagram");
			
		}
	}
}

