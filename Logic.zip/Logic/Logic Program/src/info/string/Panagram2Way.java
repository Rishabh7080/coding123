package info.string;

import java.util.Scanner;

public class Panagram2Way {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
    int flag=0;
    String s=sc.nextLine();
     s=s.toUpperCase();
     int a[]=new int[256];
     for(int i=0;i<s.length();i++)
     
     a[s.charAt(i)]++;
     for(int i=65;i<=90;i++)
     {
         if(a[i]==0)
         {
             System.out.println(0);
             flag=1;
             break;
         }
     }
     if(flag!=1)
     System.out.println(1);
 }
 	}


