package info.string;

public class Program_Polindrom {

	public static void main(String[] args) {
		String s="malajyalam", t="";
		for (int i = 0; i < s.length(); i++) {
			t=s.charAt(i)+t;
			
		}
		
		if (s.equals(t)) {
			System.out.println("polindrome");
		}
		else
			System.out.println("not polindrome");

	}

}
