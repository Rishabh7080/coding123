package info.string;

public class RemoveDigit_OF_String {
public static void main(String[] args) {
	String s="esuhdb828376789!@##";
	String t="";
	for(int i=0;i<s.length();i++)
	{char c=s.charAt(i);
		//if(Character.isDigit(c))
	//if(Character.isAlphabetic(c))
	if(c>='0'&&c<58)
		{
		
		}
		else
		{
			t=t+c;
		}
	}
	System.out.println(t);
}
}
