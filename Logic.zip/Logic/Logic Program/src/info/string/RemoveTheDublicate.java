package info.string;

import java.util.Arrays;

public class RemoveTheDublicate {

	public static void main(String[] args) {
     String s="RishabhMishra";
     char ar[]=s.toCharArray();
     Arrays.sort(ar);
     s=new String(ar);
     while(s.length()>0)
     {
    	 char c=s.charAt(0);
    	 int occ=s.lastIndexOf(c)+1;
    	 System.out.println(""+c+occ);
    	 s=s.replace(""+c,"");
     }
	}

}
