package info.string;

public class Remove_Dublicate_Anaother {

	public static void main(String[] args) {
		String s="banaanas";
		String t="";
		
		for (int i = 0; i<s.length(); i++) 
		{
			char c=s.charAt(i);
			if (t.contains(""+c)) {
				
			       }
			else {
				t=t+c;
				
			}
			
		}
		System.out.println(t);

	}

}
