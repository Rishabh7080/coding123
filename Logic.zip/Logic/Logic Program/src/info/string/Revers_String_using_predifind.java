package info.string;

public class Revers_String_using_predifind {

	public static void main(String[] args) {
		int n=1821;
		String s=""+n;
		StringBuffer sb= new StringBuffer(s);
		sb.reverse();
		if(s.equals(""+sb))
			System.out.println("polindrom");
		else
			System.out.println("not polindrom");
	}

	

}
