package info.string;
import java.util.Scanner;
public class ReverseOrpolindrom {


		public static void main(String[] args) {
			String rev="";
			String s1;
			Scanner sc=new Scanner(System.in);
			System.out.println("Eneter the String");
			s1=sc.nextLine();
			   int length=s1.length();
			   for (int i =length-1; i >=0 ; i--) {
				   rev=rev+s1.charAt(i);
				
			}
			   System.out.println("Reverse is\t"+rev);
			   if(s1.equals(rev))
				   System.out.println("polindrom");
			   else System.out.println("not polindrom");

		}

	
}
