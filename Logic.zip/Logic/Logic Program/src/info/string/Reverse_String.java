package info.string;

public class Reverse_String {

	public static void main(String[] args) {

      String s="abcd";String t="";
      for (int i = 0;i<s.length();i++) {
		//System.out.print(s.charAt(i));
    	  t=s.charAt(i)+t;
	}
     System.out.println(t);
	}

}
