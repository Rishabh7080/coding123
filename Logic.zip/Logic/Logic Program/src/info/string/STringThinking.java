package info.string;

import java.util.Scanner;

class GFG {
	public static void main (String[] args) {
		Scanner sc=new Scanner(System.in);
		int N=sc.nextInt(); sc.nextLine();
		while(N-->0)
		{ int count=1;
		    String s=sc.nextLine();
		     char ar[]=s.toCharArray();
		    
		     for(int j=1;j<ar.length;j++)
		     {
		         if(ar[j]>='A' && ar[j]<='Z')
		         {
		             count++;
		         }
		         System.out.println(count);
		     }
		}
	}
}