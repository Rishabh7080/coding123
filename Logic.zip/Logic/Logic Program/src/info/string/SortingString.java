package info.string;

import java.util.Arrays;

public class SortingString {

	public static void main(String[] args) {
	String s="jjnnaskhiufewcsbhbacbcdqbdacsbfvbfwecsbhb";
	                char ch[]= s.toCharArray();
	           Arrays.sort(ch);
	           String s1=new String(ch);
	           System.out.println(s1);

	}

}
