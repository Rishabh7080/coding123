package info.string;

import java.security.acl.LastOwnerException;

public class StringClassInbuitMethod {

	public static void main(String[] args) {
		String s=new String("rama");
		String t=new String("rama");
		String p="rama";
		String q="rama";
		StringBuffer sb=new StringBuffer();
		System.out.println(s==t);
		System.out.println(p==q);
		System.out.println(s==p);
		//System.out.println(s==sb);// error boez s is string is sb is stringbuffer how can be possible
		System.out.println(s.equals(t));
		System.out.println(s.equals(p));
		System.out.println(s.equals(sb));// becoz reference type is differernt so answer is false
	    
		
		
		String a="Rishabh";//convert to Uppercase
		System.out.println(a.toUpperCase());
		System.out.println(a.toLowerCase());
		
		System.out.println(a);
		
		StringBuffer sb1=new StringBuffer("rama");
		System.out.println(sb1.reverse());
		System.out.println(sb1);
		
		
		String s1="bananas";
               int n=s1.length();
              System.out.println(n);
                  char ch=s1.charAt(5);
                  System.out.println(ch);
                  
                  
                  String s3="bananas";
                  
                 int n1= s3.indexOf('n');
                 System.out.println(n1);
                 String s4="bananas";
                 int n2=s3.indexOf('a',2);
                 System.out.println(n2);
                 int n3=s4.lastIndexOf('a');
                 System.out.println(n3);
                 
                 
                 
                 
                 String str="bananas";
                    str= str.substring(2, 6);
                    System.out.println(str);
                    str=str.replace("a", "x");
                    System.out.println(str);
                    str=str.replaceFirst("x", "b");
                    System.out.println(str);
                    
                    
                    
                    
                    
                    String ab="bananas";
                   ab= ab.replace("a", "");
                   System.out.println(ab);
                   
                   
                   String abc=("   thsi  is  saajnaj");
                          abc=abc.replace(" ", "");
                          System.out.println(abc);
                    
                 
                 
                 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
