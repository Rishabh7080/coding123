package info.string;

public class StringRevTor {

	public static void main(String[] args) {
	 String s="I Love you";
	 String t="";
	 String sf=s.substring(2,6);
	 for(int i=0;i<sf.length();i++)
	 {
		 t=sf.charAt(i)+t;
	 }
	String fs=s.substring(7,10);
	 
	
	 System.out.println(s.charAt(0)+" "+t+" "+fs);

	}

}
