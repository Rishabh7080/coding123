package info.string;

import java.util.Scanner;

public class StringReverseEachWord {

	public static void main(String[] args) {
		String s="I Love You";
		      String [] ar  =s.split(" ");//[I,Love,You]
		      String t="";
		      for(int i=0;i<ar.length;i++)
		      {
		    	  String ars=ar[i];
		    	  //           =[I]
		    	  //          ==[Love]
		    	  //         =[You]
		    	  String rev="";
		      
		      for(int j=ars.length()-1;j>=0;j--)
		      {
		    	  rev= rev+ars.charAt(j);
		      }
		      t=t+rev+" ";
		      }
System.out.println(t);
		
		
		}

	}



