package info.string;



public class StringSumDigitmid {

	public static void main(String[] args) {
		String s="RIsabdbhb12jsb55vkh55";
		
		 int sum = 0;
		 String a[] = s.split("\\D");
		
	for(int i =0; i<a.length;i++){
		
		
		    if(!a[i].isEmpty()){
		         sum = sum + Integer.parseInt(a[i]);
		         }
		 }
		
		System.out.println(sum);
	}

}
