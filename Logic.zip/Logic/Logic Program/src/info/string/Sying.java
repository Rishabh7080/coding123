package info.string;

import java.util.Scanner;

public class Sying {

	public static void main(String[] args) {
		String s= "abc345def6kl67";
		String t="";
		String v="";
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if(c>=97&&c<=122)
			{
				t=t+c;
			}
			else {
				v+=c;
			}
		}
System.out.println(t);
System.out.println();
	}

}
