package info.string;

public class Write_a_program_to_char {

	public static void main(String[] args) {
		String s="bananas";
		char c='n';
		s=s.replace(""+c,"");
		System.out.println(s);
		

	}

}
