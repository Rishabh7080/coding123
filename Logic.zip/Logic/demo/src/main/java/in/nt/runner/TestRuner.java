package in.nt.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Component
@ConfigurationProperties(prefix = "my.app")
@Setter
@Getter
@ToString
public class TestRuner implements CommandLineRunner {

	private String name;
	private String course;
	private float[] exp;
	public void run(String... args) throws Exception {
		System.out.println(this);

	}

}
